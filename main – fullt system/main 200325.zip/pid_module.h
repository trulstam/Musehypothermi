#ifndef PID_MODULE_H
#define PID_MODULE_H

#include <PID_v1.h>
#include "eeprom_manager.h"

// Pin-oppkobling
#define ENA_PIN 6
#define IN1_PIN 8
#define IN2_PIN 7

class PIDModule {
public:
    PIDModule();

    void begin(EEPROMManager &eepromManager);
    void update(double currentTemp);
    void updateProfile();  // ✅ Profilhåndtering

    // PID kontroll
    void start();
    void stop();
    bool isActive();

    // Autotune
    void startAutotune();
    bool isAutotuneActive();
    void runAutotune();

    // PID parametre
    void setKp(float value);
    void setKi(float value);
    void setKd(float value);
    void setTargetTemp(float value);
    void setMaxOutputPercent(float percent);

    float getKp();
    float getKi();
    float getKd();
    float getTargetTemp();
    float getMaxOutputPercent();

    float getOutput();
    float getCurrentInput();
    float getPwmOutput();

    // Debugging
    void enableDebug(bool enable);
    bool isDebugEnabled();
    void sendDebug();  // ✅ Ny debug-funksjon

    // Manuell styring
    void manualOutput(float outputValue);
    bool isManualMode();

    // Temperaturprofil-funksjoner
    struct ProfileStep {
        float time;  // minutter
        float temp;  // grader Celsius
    };

    void loadProfile(ProfileStep *profileSteps, int length);
    bool isProfileActive();

private:
    void applyOutputLimit();
    void applyPIDOutput();
    void applyManualOutput();
    void setPeltierOutput(double output);
    void calculateZieglerNicholsParams();

    PID pid;
    EEPROMManager *eeprom;

    // PID variabler
    double Input;
    double Output;
    double Setpoint;

    // PWM-verdier
    double pwmValue;
    int currentPWM;

    // PID-parametre
    float kp, ki, kd;
    float maxOutputPercent;

    bool active;
    bool autotuneActive;

    // Autotune variabler
    double relayAmplitude;
    bool relayState;
    unsigned long relayStartTime;
    unsigned long lastToggleTime;
    double Ku, Pu;
    int cycleCount;

    // Debug og manuell modus
    bool debugEnabled;
    bool manualMode;
    float manualOutputValue;

    // Temperaturprofil
    ProfileStep profile[10];           // Maks 10 steg
    int profileLength = 0;             // Antall steg i profilen
    int currentProfileStep = 0;        // Steg som kjøres nå
    unsigned long profileStartMillis = 0;  // Tidspunkt for start
    bool profileActive = false;

    // Standard PID konstanter
    static constexpr float defaultKp = 2.0;
    static constexpr float defaultKi = 0.5;
    static constexpr float defaultKd = 1.0;
};

#endif
