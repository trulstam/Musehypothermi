#include "comm_api.h"
#include "pid_module.h"
#include "sensor_module.h"
#include "pressure_module.h"
#include "eeprom_manager.h"
#include "task_scheduler.h"  // For failsafe status
#include <ArduinoJson.h>

// Eksterne instanser
extern PIDModule pid;
extern SensorModule sensors;
extern PressureModule pressure;
extern EEPROMManager eeprom;
extern void heartbeatReceived();  // Importer fra main.ino


// === Constructor / init ===
CommAPI::CommAPI(Stream &serialStream) {
    serial = &serialStream;
    buffer = "";
}

void CommAPI::begin(Stream &serialStream) {
    serial = &serialStream;
    buffer = "";
}

// === Process incoming serial ===
void CommAPI::process() {
    while (serial->available()) {
        char c = serial->read();
        if (c == '\n') {
            handleCommand(buffer);
            buffer = "";
        } else {
            buffer += c;
        }
    }
}

// === Handle incoming JSON ===
void CommAPI::handleCommand(const String &jsonString) {
    StaticJsonDocument<1024> doc;
    DeserializationError error = deserializeJson(doc, jsonString);

    if (error) {
        sendResponse("JSON parse error");
        return;
    }

    // === CMD ===
    if (doc.containsKey("CMD")) {
        JsonObject cmd = doc["CMD"];
        String action = cmd["action"];
        String state = cmd["state"];

        if (action == "pid") {
            if (state == "start") {
                pid.start();
                sendResponse("PID started");
            } else if (state == "stop") {
                pid.stop();
                sendResponse("PID stopped");
            } else if (state == "autotune") {
                pid.startAutotune();
                sendResponse("Autotune started");
            } else {
                sendResponse("Unknown PID state");
            }

        } else if (action == "heartbeat") {
            heartbeatReceived();  // <- Pass på at denne finnes i main.ino
            sendResponse("heartbeat_ack");

        } else if (action == "get") {
            if (state == "pid_params") {
                sendPIDParams();
            } else if (state == "data") {
                sendData();
            } else {
                sendResponse("Unknown GET action");
            }

        } else if (action == "failsafe_clear") {
            clearFailsafe();
            sendResponse("Failsafe cleared");

        } else {
            sendResponse("Unknown CMD action");
        }
    }

    // === SET ===
    if (doc.containsKey("SET")) {
        JsonObject set = doc["SET"];
        String variable = set["variable"];

        float value = set["value"];  // Default value extraction for float

        if (variable == "target_temp") {
            pid.setTargetTemp(value);
            eeprom.saveTargetTemp(value);
            sendResponse("Target temperature updated");

        } else if (variable == "pid_kp") {
            pid.setKp(value);
            eeprom.savePIDParams(pid.getKp(), pid.getKi(), pid.getKd());
            sendResponse("Kp updated");

        } else if (variable == "pid_ki") {
            pid.setKi(value);
            eeprom.savePIDParams(pid.getKp(), pid.getKi(), pid.getKd());
            sendResponse("Ki updated");

        } else if (variable == "pid_kd") {
            pid.setKd(value);
            eeprom.savePIDParams(pid.getKp(), pid.getKi(), pid.getKd());
            sendResponse("Kd updated");

        } else if (variable == "pid_max_output") {
            pid.setMaxOutputPercent(value);
            sendResponse("Max output limit updated");

        } else if (variable == "profile") {
            JsonArray profileArray = set["value"].as<JsonArray>();
            parseProfile(profileArray);

        } else {
            sendResponse("Unknown SET variable");
        }
    }
}

// === Profile parsing ===
void CommAPI::parseProfile(JsonArray arr) {
    const int profileLen = arr.size();

    if (profileLen == 0 || profileLen > 10) {
        sendResponse("Invalid profile length");
        return;
    }

    PIDModule::ProfileStep steps[10];  // Maks 10 steg
    for (int i = 0; i < profileLen; i++) {
        float timeVal = arr[i]["time"] | -1;
        float tempVal = arr[i]["temp"] | -999;

        if (timeVal < 0 || tempVal < -50 || tempVal > 50) {
            sendResponse("Invalid profile step");
            return;
        }

        steps[i].time = timeVal;
        steps[i].temp = tempVal;
    }

    pid.loadProfile(steps, profileLen);
    sendResponse("Profile loaded");
}

// === Response ===
void CommAPI::sendResponse(const String &message) {
    StaticJsonDocument<256> doc;
    doc["response"] = message;
    serializeJson(doc, *serial);
    serial->println();
}

// === Data sending ===
void CommAPI::sendData() {
    StaticJsonDocument<1024> doc;

    // Sensor + PID data
    doc["cooling_plate_temp"] = sensors.getCoolingPlateTemp();
    doc["anal_probe_temp"]    = sensors.getRectalTemp();
    doc["pid_output"]         = pid.getOutput();
    doc["breath_freq_bpm"]    = pressure.getBreathRate();

    // Failsafe status
    if (isFailsafeActive()) {
        doc["failsafe"] = true;
    } else {
        doc["failsafe"] = false;
    }

    // Debug-data
    JsonObject debug = doc.createNestedObject("debug");
    debug["Input"]    = pid.getCurrentInput();
    debug["Output"]   = pid.getOutput();
    debug["Setpoint"] = pid.getTargetTemp();
    debug["PWM"]      = pid.getPwmOutput();

    serializeJson(doc, *serial);
    serial->println();
}

// === PID param sending ===
void CommAPI::sendPIDParams() {
    StaticJsonDocument<256> doc;

    doc["pid_kp"] = pid.getKp();
    doc["pid_ki"] = pid.getKi();
    doc["pid_kd"] = pid.getKd();
    doc["pid_max_output"] = pid.getMaxOutputPercent();

    serializeJson(doc, *serial);
    serial->println();
}
