// Musehypothermi EEPROM Manager for Arduino Uno R4 Minima
// File: eeprom_manager.h

#ifndef EEPROM_MANAGER_H
#define EEPROM_MANAGER_H

#include <Arduino.h>
#include <EEPROM.h>

class EEPROMManager {
  public:
    void begin();  // Ikke nødvendig for Uno R4 Minima, men beholdt for konsistens.

    void savePIDParams(float kp, float ki, float kd);
    void loadPIDParams(float &kp, float &ki, float &kd);

    void saveTargetTemp(float temp);
    void loadTargetTemp(float &temp);

  private:
    // EEPROM-adresser for lagring av variabler
    static const int addrKp = 0;
    static const int addrKi = addrKp + sizeof(float);
    static const int addrKd = addrKi + sizeof(float);
    static const int addrTargetTemp = addrKd + sizeof(float);
};

#endif  // EEPROM_MANAGER_H
