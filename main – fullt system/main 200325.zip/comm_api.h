#ifndef COMM_API_H
#define COMM_API_H

#include <Arduino.h>
#include <ArduinoJson.h>

class CommAPI {
public:
    CommAPI(Stream &serialStream);
    void begin(Stream &serialStream);
    void process();

    void sendData();
    void sendPIDParams();
    void sendResponse(const String &message);

private:
    void handleCommand(const String &jsonString);
    void parseProfile(JsonArray arr);   // <--- Ny!

    Stream *serial;
    String buffer;
};

#endif
