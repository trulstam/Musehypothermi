#include "pid_module.h"
#include <Arduino.h>
#include <ArduinoJson.h>

// PWM område
#define MAX_PWM 50

PIDModule::PIDModule()
    : pid(&Input, &Output, &Setpoint, defaultKp, defaultKi, defaultKd, DIRECT),
      kp(defaultKp), ki(defaultKi), kd(defaultKd),
      maxOutputPercent(20.0), active(false), autotuneActive(false),
      relayAmplitude(0.0), relayState(false), relayStartTime(0),
      lastToggleTime(0), Ku(0), Pu(0), cycleCount(0),
      Input(0), Output(0), Setpoint(20.0),
      pwmValue(0), currentPWM(0),
      debugEnabled(false), manualMode(false), manualOutputValue(0),
      profileLength(0), currentProfileStep(0), profileStartMillis(0), profileActive(false)
{}

// === INITIALISERING ===
void PIDModule::begin(EEPROMManager &eepromManager) {
    eeprom = &eepromManager;

    float eepromKp, eepromKi, eepromKd;
    eeprom->loadPIDParams(eepromKp, eepromKi, eepromKd);
    setKp(eepromKp);
    setKi(eepromKi);
    setKd(eepromKd);

    float targetTemp;
    eeprom->loadTargetTemp(targetTemp);
    setTargetTemp(targetTemp);

    pinMode(ENA_PIN, OUTPUT);
    pinMode(IN1_PIN, OUTPUT);
    pinMode(IN2_PIN, OUTPUT);

    digitalWrite(IN1_PIN, LOW);
    digitalWrite(IN2_PIN, LOW);
    analogWrite(ENA_PIN, 0);

    pid.SetSampleTime(100); // 100 ms
    pid.SetMode(MANUAL);
    applyOutputLimit();
}

// === MAIN UPDATE LOOP ===
void PIDModule::update(double currentTemp) {
    Input = currentTemp;

    if (manualMode) {
        applyManualOutput();
        return;
    }

    if (autotuneActive) {
        runAutotune();
        return;
    }

    if (profileActive) {
        updateProfile();
    }

    if (!active) {
        setPeltierOutput(0);
        return;
    }

    pid.Compute();
    applyPIDOutput();

    if (debugEnabled) {
        sendDebug();
    }
}

// === PID OUTPUT ===
void PIDModule::applyPIDOutput() {
    pwmValue = Output;
    setPeltierOutput(pwmValue);
}

void PIDModule::applyManualOutput() {
    pwmValue = manualOutputValue;
    setPeltierOutput(pwmValue);
}

// === START / STOP ===
void PIDModule::start() {
    pid.SetMode(AUTOMATIC);
    active = true;
    manualMode = false;
    profileStartMillis = millis();
    applyOutputLimit();
}

void PIDModule::stop() {
    pid.SetMode(MANUAL);
    active = false;
    manualMode = false;
    profileActive = false;
    setPeltierOutput(0);
}

bool PIDModule::isActive() { return active; }

// === AUTOTUNE ===
void PIDModule::startAutotune() {
    stop();
    autotuneActive = true;
    relayState = false;

    relayAmplitude = (MAX_PWM * (maxOutputPercent / 100.0)) * 0.2; // 20% av maks PWM
    relayStartTime = millis();
    lastToggleTime = millis();
    cycleCount = 0;

    if (debugEnabled) {
        Serial.println("{\"autotune\": \"started\"}");
    }
}

bool PIDModule::isAutotuneActive() { return autotuneActive; }

void PIDModule::runAutotune() {
    if (!autotuneActive) return;

    unsigned long now = millis();
    unsigned long relayPeriod = 10000; // 10 sekunder toggle

    if (now - lastToggleTime >= relayPeriod) {
        relayState = !relayState;
        lastToggleTime = now;
        cycleCount++;

        if (debugEnabled) {
            StaticJsonDocument<256> doc;
            doc["autotune"] = "relay_toggle";
            doc["cycle"] = cycleCount;
            doc["relay_state"] = relayState ? "HIGH" : "LOW";
            doc["relay_amplitude"] = relayAmplitude;
            doc["time_sec"] = (now - relayStartTime) / 1000.0;
            serializeJson(doc, Serial);
            Serial.println();
        }

        if (cycleCount >= 6) {
            autotuneActive = false;
            calculateZieglerNicholsParams();
            return;
        }
    }

    pwmValue = relayState ? relayAmplitude : 0;
    setPeltierOutput(pwmValue);
}

void PIDModule::calculateZieglerNicholsParams() {
    Ku = 6.0; // Dummyverdier
    Pu = 10.0;

    kp = 0.6 * Ku;
    ki = 2 * kp / Pu;
    kd = kp * Pu / 8;

    pid.SetTunings(kp, ki, kd);
    if (eeprom) {
        eeprom->savePIDParams(kp, ki, kd);
    }

    applyOutputLimit();

    if (debugEnabled) {
        StaticJsonDocument<256> doc;
        doc["autotune"] = "complete";
        doc["kp"] = kp;
        doc["ki"] = ki;
        doc["kd"] = kd;
        serializeJson(doc, Serial);
        Serial.println();
    }
}

// === PWM UTGANG ===
void PIDModule::applyOutputLimit() {
    int pwmMaxValue = (int)(MAX_PWM * (maxOutputPercent / 100.0));
    pid.SetOutputLimits(-pwmMaxValue, pwmMaxValue);
}

void PIDModule::setPeltierOutput(double outVal) {
    currentPWM = constrain((int)(abs(outVal)), 0, MAX_PWM);

    if (outVal > 0.0) {
        digitalWrite(IN1_PIN, LOW);
        digitalWrite(IN2_PIN, HIGH);
        analogWrite(ENA_PIN, currentPWM);
    } else if (outVal < 0.0) {
        digitalWrite(IN1_PIN, HIGH);
        digitalWrite(IN2_PIN, LOW);
        analogWrite(ENA_PIN, currentPWM);
    } else {
        digitalWrite(IN1_PIN, LOW);
        digitalWrite(IN2_PIN, LOW);
        analogWrite(ENA_PIN, 0);
    }
}

// === GETTERS ===
float PIDModule::getKp() { return kp; }
float PIDModule::getKi() { return ki; }
float PIDModule::getKd() { return kd; }
float PIDModule::getTargetTemp() { return Setpoint; }
float PIDModule::getOutput() { return Output; }
float PIDModule::getCurrentInput() { return Input; }
float PIDModule::getPwmOutput() { return pwmValue; }
float PIDModule::getMaxOutputPercent() { return maxOutputPercent; }

// === SETTERS ===
void PIDModule::setKp(float value) { kp = value; pid.SetTunings(kp, ki, kd); }
void PIDModule::setKi(float value) { ki = value; pid.SetTunings(kp, ki, kd); }
void PIDModule::setKd(float value) { kd = value; pid.SetTunings(kp, ki, kd); }
void PIDModule::setTargetTemp(float value) { Setpoint = value; }

void PIDModule::setMaxOutputPercent(float percent) {
    maxOutputPercent = constrain(percent, 0.0, 100.0);
    applyOutputLimit();
}

// === DEBUG ===
void PIDModule::enableDebug(bool enable) { debugEnabled = enable; }
bool PIDModule::isDebugEnabled() { return debugEnabled; }

void PIDModule::sendDebug() {
    StaticJsonDocument<256> doc;
    doc["debug"]["Input"] = Input;
    doc["debug"]["Output"] = Output;
    doc["debug"]["Setpoint"] = Setpoint;
    doc["debug"]["PWM"] = pwmValue;
    serializeJson(doc, Serial);
    Serial.println();
}

// === MANUAL MODE ===
void PIDModule::manualOutput(float outputValue) {
    manualMode = true;
    active = false;
    profileActive = false;
    manualOutputValue = constrain(outputValue, -MAX_PWM, MAX_PWM);
}

bool PIDModule::isManualMode() { return manualMode; }

// === PROFILE ===
void PIDModule::loadProfile(ProfileStep *profileSteps, int length) {
    if (length > 10) length = 10;

    for (int i = 0; i < length; i++) {
        profile[i] = profileSteps[i];
    }

    profileLength = length;
    currentProfileStep = 0;
    profileActive = (profileLength > 0);
    profileStartMillis = millis();

    if (profileActive) {
        setTargetTemp(profile[0].temp);
    }

    if (debugEnabled) {
        StaticJsonDocument<256> doc;
        doc["profile"] = "loaded";
        doc["steps"] = profileLength;
        serializeJson(doc, Serial);
        Serial.println();
    }
}

void PIDModule::updateProfile() {
    if (!profileActive || profileLength == 0) return;

    unsigned long elapsedMillis = millis() - profileStartMillis;
    float elapsedMinutes = elapsedMillis / 60000.0;

    if (currentProfileStep + 1 < profileLength &&
        elapsedMinutes >= profile[currentProfileStep + 1].time) {

        currentProfileStep++;
        setTargetTemp(profile[currentProfileStep].temp);

        if (debugEnabled) {
            StaticJsonDocument<256> doc;
            doc["profile"] = "step_advanced";
            doc["step"] = currentProfileStep;
            doc["setpoint"] = profile[currentProfileStep].temp;
            serializeJson(doc, Serial);
            Serial.println();
        }
    }

    if (currentProfileStep + 1 >= profileLength &&
        elapsedMinutes >= profile[currentProfileStep].time) {

        profileActive = false;

        if (debugEnabled) {
            StaticJsonDocument<256> doc;
            doc["profile"] = "completed";
            serializeJson(doc, Serial);
            Serial.println();
        }
    }
}

bool PIDModule::isProfileActive() { return profileActive; }
