// Musehypothermi EEPROM Manager for Arduino Uno R4 Minima
// File: eeprom_manager.cpp

#include "eeprom_manager.h"
#include <EEPROM.h>

// Ingen EEPROM.begin() kreves for Arduino Uno R4 Minima.

void EEPROMManager::begin() {
    // Tom på Uno R4 Minima. Kan brukes for fremtidig kode.
}

void EEPROMManager::savePIDParams(float kp, float ki, float kd) {
    EEPROM.put(addrKp, kp);
    EEPROM.put(addrKi, ki);
    EEPROM.put(addrKd, kd);

    // EEPROM.commit();  // Ikke nødvendig på Uno R4 Minima.
}

void EEPROMManager::loadPIDParams(float &kp, float &ki, float &kd) {
    EEPROM.get(addrKp, kp);
    EEPROM.get(addrKi, ki);
    EEPROM.get(addrKd, kd);

    // Valgfritt debug-utskrift:
    /*
    Serial.print("Loaded PID params: Kp=");
    Serial.print(kp);
    Serial.print(" Ki=");
    Serial.print(ki);
    Serial.print(" Kd=");
    Serial.println(kd);
    */
}

void EEPROMManager::saveTargetTemp(float temp) {
    EEPROM.put(addrTargetTemp, temp);

    // EEPROM.commit();  // Ikke nødvendig.
}

void EEPROMManager::loadTargetTemp(float &temp) {
    EEPROM.get(addrTargetTemp, temp);

    // Valgfritt debug-utskrift:
    /*
    Serial.print("Loaded Target Temp: ");
    Serial.println(temp);
    */
}
