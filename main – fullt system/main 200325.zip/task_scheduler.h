// Musehypothermi Arduino Task Scheduler Module
// File: task_scheduler.h

#ifndef TASK_SCHEDULER_H
#define TASK_SCHEDULER_H

// Init og hovedloop
void initTasks();
void runTasks();

// Failsafe kontroll
void triggerFailsafe(const char* reason);
void clearFailsafe();
bool isFailsafeActive();

#endif // TASK_SCHEDULER_H
