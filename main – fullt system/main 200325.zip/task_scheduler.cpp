// Musehypothermi Arduino Task Scheduler Module
// File: task_scheduler.cpp

#include "task_scheduler.h"
#include "pid_module.h"
#include "sensor_module.h"
#include "pressure_module.h"
#include <Arduino.h>

// Eksterne moduler
extern PIDModule pid;
extern SensorModule sensors;
extern PressureModule pressure;

// Timing vars
unsigned long previousPIDMillis = 0;
unsigned long previousSensorMillis = 0;
unsigned long previousPressureMillis = 0;

// Intervaller (ms)
const unsigned long PID_INTERVAL = 100;        // 10 Hz
const unsigned long SENSOR_INTERVAL = 500;     // 2 Hz
const unsigned long PRESSURE_INTERVAL = 4;     // 250 Hz

// Failsafe status
bool failsafeTriggered = false;

// === INIT ===
void initTasks() {
    previousPIDMillis = millis();
    previousSensorMillis = millis();
    previousPressureMillis = millis();
    failsafeTriggered = false;
}

// === TASKS ===
void runTasks() {
    unsigned long currentMillis = millis();

    // FAILSAFE: Stopp PID hvis aktiv
    if (failsafeTriggered) {
        if (pid.isActive()) {
            pid.stop();
            if (pid.isDebugEnabled()) {
                Serial.println(F("{\"failsafe\": \"Failsafe active - PID stopped\"}"));
            }
        }
        return;
    }

    // PID & Profil
    if (currentMillis - previousPIDMillis >= PID_INTERVAL) {
        previousPIDMillis = currentMillis;

        if (pid.isAutotuneActive()) {
            pid.runAutotune();
        } else if (pid.isActive()) {
            pid.update(sensors.getCoolingPlateTemp());
        }
    }

    // Sensorer
    if (currentMillis - previousSensorMillis >= SENSOR_INTERVAL) {
        previousSensorMillis = currentMillis;
        sensors.update();
    }

    // Pustemåling
    if (currentMillis - previousPressureMillis >= PRESSURE_INTERVAL) {
        previousPressureMillis = currentMillis;
        pressure.update();
    }
}

// === FAILSAFE ===
void triggerFailsafe(const char* reason) {
    if (failsafeTriggered) return;  // Unngå dobbelt-triggering

    failsafeTriggered = true;

    Serial.print(F("{\"failsafe\": \"Triggered: "));
    Serial.print(reason);
    Serial.println(F("\"}"));

    pid.stop();
}

void clearFailsafe() {
    failsafeTriggered = false;
    Serial.println(F("{\"failsafe\": \"Cleared\"}"));
}

bool isFailsafeActive() {
    return failsafeTriggered;
}
